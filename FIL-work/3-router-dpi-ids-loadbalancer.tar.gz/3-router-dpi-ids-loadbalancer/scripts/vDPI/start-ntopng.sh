#!/bin/bash

set -e

sudo service ntopng start
