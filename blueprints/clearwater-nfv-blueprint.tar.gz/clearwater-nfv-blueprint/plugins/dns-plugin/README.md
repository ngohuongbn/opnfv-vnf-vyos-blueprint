cloudify-plugin-template
========================

Cloudify plugin project template
