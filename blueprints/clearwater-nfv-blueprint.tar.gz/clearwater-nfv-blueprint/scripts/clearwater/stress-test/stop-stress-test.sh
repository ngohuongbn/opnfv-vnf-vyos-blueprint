#!/usr/bin/env bash

sudo service clearwater-sipp-stress stop