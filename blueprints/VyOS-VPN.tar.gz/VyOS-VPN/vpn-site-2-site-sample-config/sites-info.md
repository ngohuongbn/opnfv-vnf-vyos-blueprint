## Sample info
- Site A: 
  - PUBLIC address: 192.168.0.20/24
  - PUBLIC interface: eth0
  - LAN prefix: 10.0.0.0/24

- Site B:
  - PUBLIC address: 192.168.0.21/24
  - LAN prefix: 10.1.0.0/24
  - PUBLIC interface: eth0
