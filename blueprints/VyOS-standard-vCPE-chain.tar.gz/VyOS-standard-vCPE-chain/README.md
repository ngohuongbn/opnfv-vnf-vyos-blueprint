# Standard service function chain for vCPE usecases

- List of service functions are picked out: vRouter - vFirewall - vWAN Optimizer
  - vRouter: VyOS 1.1.7
  - vFirewall: iptables + ntopng
  - vWAN Optimizer: wanos